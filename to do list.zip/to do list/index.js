function add()
{
    var taskname=document.getElementById('taskname').value
    var mylist = document.getElementById('mylist')

    var newtodoitem = document.createElement('div')

    var todoname = document.createElement('li')

    todoname.innerText=taskname
    var deletebtn = document.createElement('i')
    deletebtn.classList.add('fa')
    deletebtn.classList.add('fa-trash')

    newtodoitem.appendChild(todoname)
    newtodoitem.appendChild(deletebtn)

    mylist.appendChild(newtodoitem)
    mylist.addEventListener('click',deleteitem)
}


function deleteitem(e)
{
    var del =0
    const element=e.target
    if(element.classList[0]=='fa')
    {
        element.parentElement.remove()
        alert(`${element.parentElement.innerText} is deleted.`)
    }
}