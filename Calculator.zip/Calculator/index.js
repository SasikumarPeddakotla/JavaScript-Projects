function display(value)
{
    document.getElementById('inputarea').value+=value
}

function calculate()
{
    var dis = document.getElementById('inputarea').value
    document.getElementById('inputarea').value = eval(dis)
}

function clr()
{
    document.getElementById('inputarea').value=''
}

