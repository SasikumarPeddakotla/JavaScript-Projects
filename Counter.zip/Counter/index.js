function increment()
{
    var number=Number(document.getElementById("counter").innerHTML)
    document.getElementById("counter").innerHTML = number+1
}

function decrement()
{
    var number=(document.getElementById("counter").innerHTML)
    document.getElementById("counter").innerHTML = number-1
}

function reset()
{
    document.getElementById("counter").innerHTML = 0
}