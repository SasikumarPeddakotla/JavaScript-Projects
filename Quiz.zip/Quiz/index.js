var quizdata = [
    {
        ques: 'Which is not a programming language?',
        a : 'HTML',
        b:'javascript',
        c:'java',
        d:'C',
        correct:'a'
    },
    {
        ques: 'Which is used to define variables in JS?',
        a : 'var',
        b:'let',
        c:'both a & b',
        d:'none',
        correct:'c'
    },
    {
        ques: 'Which framework belongs to JS?',
        a : '.net',
        b:'laravel',
        c:'django',
        d:'react',
        correct:'d'
    },
    {
        ques: 'Which is not a web browser?',
        a : 'safari',
        b:'photoshop',
        c:'chrome',
        d:'none',
        correct:'b'
    }
]

var quiz=document.getElementById('quiz')
var answer=document.querySelectorAll('.answer')
var question=document.getElementById('question')
var option_a = document.getElementById('a_value')
var option_b = document.getElementById('b_value')
var option_c = document.getElementById('c_value')
var option_d = document.getElementById('d_value')
var submitbtn = document.getElementById('submit')

var currentQues = 0
var quizScore = 0

loadQuiz()

function loadQuiz()
{
    deselect()

    question.innerText=quizdata[currentQues].ques
    option_a.innerText=quizdata[currentQues].a
    option_b.innerText=quizdata[currentQues].b
    option_c.innerText=quizdata[currentQues].c
    option_d.innerText=quizdata[currentQues].d
}

function deselect()
{
    answer.forEach(answer=>answer.checked=false)
}

submitbtn.addEventListener('click',()=>{

    var selectedOption;
    answer.forEach(answer=>{
        if(answer.checked)
        {
            selectedOption=answer.id
        }
    })

    if(selectedOption==quizdata[currentQues].correct)
    {
        quizScore=quizScore+1
    }
    currentQues=currentQues+1
   
    if(currentQues==quizdata.length)
    {
        document.getElementById('quiz').innerHTML=`<h4 class="text-center">Your score is ${quizScore}/${quizdata.length}</h4>`
    }
    else
    {
        loadQuiz()
    }
})
